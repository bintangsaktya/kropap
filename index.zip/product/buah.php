<!DOCTYPE html>
<html>
<head>
	<title>404 Maintenance</title>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-light-green.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
</head>
<body>
<center>Maintenance Process, please contact administrator</center>
<div class="w3-panel w3-red">
  <h3>Perhatian!</h3>
  <p>Server sedang dalam peningkatan dalam 48 jam kedepan.</p>
  Proses Maintenance :
  <div class="w3-light-grey w3-round-xxlarge">

  <div class="w3-container w3-round-xxlarge w3-green" style="width:17%">17%</div>
<p></p>
<p></p>
</div>
</div> 
</body>
</html>