<!DOCTYPE html>
<html>
<head>
	<title>Edukasi</title>
</head>
<body>
<center>
	<h1>Modul Edukasi CropUP</h1>
	<h3>Fitur ini dalam pengembangan, Sementara tampilan dan materi akan disesuaikan</h3>
	<a href="start.html">Pengenalan</a><br>
	<a href="know.html">Faktor Pendukung Pertanian</a><br>
	<a href="prospek.html">Prospek Pertanian</a><br>
	<a href="simplefarm.html">Pertanian Simple</a><br>
	<a href="plant.html">Cara Menanam Yang Baik</a><br>
</center>
</body>
</html>